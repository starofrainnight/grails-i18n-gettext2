/**
 * T9nTagLib - Tag library for translation (t9n) functions using gettext.
 * IMPORTANT NOTE: Althoug the tag attributes are named s, p, n, and so on, it is VITALLY IMPORTANT to keep their order
 * exactly like you see here. Why? When xgettext scans your code, it relies on the attribute order to find all singular
 * and plural forms of the original source texts. If you mess up the order of the attributes, xgettext will not find the
 * right strings to translate. xgettext does not know anything about named attributes.
 */
class T9nTagLib {
	
	def t9nService
	static namespace = "t9n"
	
	
	/**
	 * tr - translation of singular strings.
	 * @param s singular string to translate
	 * @param f optional arguments to messageFormat if you are using {0}, {1}... in your singular string
	 * @param locale optional argument to set the locale you want to translate to
	 * @param sourceLocale optional argument to set the locale of the original string
	 * @return translated string in singular form
	 **/
	def tr = { attrs->
		if( !attrs || !attrs.s ){
			throwTagError("Tag [tr] requires attribute [s]")
		}
		if( attrs?.c ){
			log.info("Tag [tr] does not accept attribute [c]")
		}
		if( attrs?.p ){
			log.info("Tag [tr] does not accept attribute [p]")
		}
		if( attrs?.n ){
			log.info("Tag [tr] does not accept attribute [n]")
		}
		
		// check attribute order
		if( attrs.s != attrs[0] ){
			throwTagError("Tag [tr] requires attribute [s] to be the first attribute")
		}
		
		out << t9nService.tr( s:attrs.s, f:attrs?.f, locale:attrs?.locale, sourceLocale:attrs?.sourceLocale )
	}
	 

	/**
	 * trn - translation of plural strings.
	 * @param s singular string to translate
	 * @param p plural string to translate
	 * @param n number which decides between singular and plural form
	 * @param f optional arguments to messageFormat if you are using {0}, {1}... in your singular or plural string
	 * @param locale optional argument to set the locale you want to translate to
	 * @param sourceLocale optional argument to set the locale of the original string
	 * @return translated string in singular or plural form, depending on what n is
	 **/
	def trn = { attrs ->
		if( !attrs || !attrs.s || !attrs.p || !attrs.n ){
			throwTagError("Tag [trn] requires attribute [s] [p] and [n]")
		}
		if( attrs?.c ){
			log.info("Tag [trn] does not accept attribute [c]")
		}
		
		
		// check attribute order
		if( attrs.s != attrs[0] ){
			throwTagError("Tag [trn] requires attribute [s] to be the first attribute")
		}
		if( attrs.p != attrs[1] ){
			throwTagError("Tag [trn] requires attribute [p] to be the second attribute")
		}
		if( attrs.n != attrs[2] ){
			throwTagError("Tag [trn] requires attribute [n] to be the third attribute")
		}
		
		
		out << t9nService.trn( s:attrs.s, p:attrs.p, n:attrs.n, f:attrs?.f, locale:attrs?.locale, sourceLocale:attrs?.sourceLocale )
	}
	 
	
	/**
	 * trc - translation with comment, disambiguates translation text.
	 * @param c context of the singular string
	 * @param s singular string to translate
	 * @param locale optional argument to set the locale you want to translate to
	 * @param sourceLocale optional argument to set the locale of the original string
	 * @return translated string
	 **/
	def trc = { attrs->
		if( !attrs || !attrs.c || !attrs.s ){
			throwTagError("Tag [trc] requires attribute [c] and [s]")
		}
		if( attrs?.p ){
			log.info("Tag [trc] does not accept attribute [p]")
		}
		if( attrs?.n ){
			log.info("Tag [trc] does not accept attribute [n]")
		}
		if( attrs?.f ){
			log.info("Tag [trc] does not accept attribute [f]")
		}
		
		
		// check attribute order
		if( attrs.c != attrs[0] ){
			throwTagError("Tag [trc] requires attribute [c] to be the first attribute")
		}
		if( attrs.s != attrs[1] ){
			throwTagError("Tag [trc] requires attribute [s] to be the second attribute")
		}
		
		out << t9nService.tr( c:attrs.c, s:attrs.s, locale:attrs?.locale, sourceLocale:attrs?.sourceLocale )
	}
	 
	
	/**
	 * marktr - mark for translation, but always return the original string.
	 * @param s singular string to translate
	 * @return original untranslated string
	 **/
	def marktr = { attrs->
		if( !attrs || !attrs.s ){
			throwTagError("Tag [marktr] requires attribute [s]")
		}
		if( attrs?.c ){
			log.info("Tag [marktr] does not accept attribute [c]")
		}
		if( attrs?.p ){
			log.info("Tag [marktr] does not accept attribute [p]")
		}
		if( attrs?.n ){
			log.info("Tag [marktr] does not accept attribute [n]")
		}
		if( attrs?.f ){
			log.info("Tag [marktr] does not accept attribute [f]")
		}
		if( attrs?.locale ){
			log.info("Tag [marktr] does not accept attribute [f]")
		}
		if( attrs?.f ){
			log.info("Tag [marktr] does not accept attribute [f]")
		}
		
		// check attribute order
		if( attrs.s != attrs[0] ){
			throwTagError("Tag [tr] requires attribute [s] to be the first attribute")
		}

		out << t9nService.marktr( s:attrs.s )
	}
	 
	 
	/**
	 * getCurrentLocale - get the current locale
	 * @return the current locale as a string
	 **/
	 def getCurrentLocale = { attrs->
	 	if( attrs ){
			log.info("Tag [getCurrentLocale] does not accept any attributes")
	 	}
	 	out << t9Service.tr()
	 }

}
