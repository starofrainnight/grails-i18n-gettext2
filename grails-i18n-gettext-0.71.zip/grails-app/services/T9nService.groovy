//
//   Copyright 2008 Rainer Brang
//
//   Licensed under the Apache License, Version 2.0 (the "License");
//   you may not use this file except in compliance with the License.
//   You may obtain a copy of the License at
//
//       http://www.apache.org/licenses/LICENSE-2.0
//
//   Unless required by applicable law or agreed to in writing, software
//   distributed under the License is distributed on an "AS IS" BASIS,
//   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//   See the License for the specific language governing permissions and
//   limitations under the License.
//
import java.text.MessageFormat
import java.util.Locale
import org.xnap.commons.i18n.*
import org.codehaus.groovy.grails.commons.ApplicationHolder
import org.springframework.web.context.request.RequestContextHolder as RCH

class T9nService {

    boolean transactional = false

    /**
     * @return the currently selected locale
     */
   	public String tr() {
		return getCurrentLocale()
	}
    
    
    
    /**
     * @param single - the text to translate
     * @return the translation of single
     */
	public String tr( String single ){
    	tr( single, null )
	}     

    /**
     * @param single - the text to translate
     * @param locale - the locale to translate into
     * @return the translation of single
     */
	public String tr( String single, String locale ){
		def i18n = getI18nObject( locale )
		return i18n?i18n.tr(single):single
	}    	

    
    
    /**
     * @param single - the text to translate
     * @param messages - the messageFormat of single
     * @return the translation of single
     */
	public String tr( String single, Object messages ){
    	tr( single, messages, null )
	}    	

    /**
     * @param single - the text to translate
     * @param messages - the messageFormat of single
     * @param locale - the locale to translate into
     * @return the translation of single
     */
	public String tr( String single, Object messages, String locale ){
		def i18n = getI18nObject( locale )
		return i18n?i18n.tr(single, (Object[])messages):MessageFormat.format(single, (Object[])messages)
	}    	
	

	
	
	// Returns the plural form for n of the translation of text.
	public String trn( String single, String plural, int number, Object messages ){
		trn( single, plural, number, messages, null )
	}

	public String trn( String single, String plural, int number, Object messages, String locale ){
		def i18n = getI18nObject( locale )
		return i18n?i18n.trn( single, plural, number, (Object[])messages ):number>1?MessageFormat.format(plural, (Object[])messages):MessageFormat.format(single, (Object[])messages)
	}


	
	// Returns the plural form for n of the translation of text.
	public String trn( String single, String plural, int number ){
		trn( single, plural, number, null )
	}

	public String trn( String single, String plural, int number, String locale ){
		def i18n = getI18nObject( locale )
		return i18n?i18n.trn( single, plural, number ):number>1?plural:single
	}


	
   	

	
	// Disambiguates translation keys
	public String trc( String comment, String text ){
		return trc( comment, text, null )
	}    	

	public String trc( String comment, String text, String locale ){
		return trc( comment, text, locale, null )
	}

	public String trc( String comment, String text, String locale, String sourceCodeLocale ){
		def i18n = getI18nObject( locale, sourceCodeLocale )
		return i18n?i18n.trc(comment, text, false):text
	}

	
	public String marktr( String text ){
		def i18n = getI18nObject( null, ApplicationHolder?.application?.config?.I18nGettext?.sourceCodeLocale ?:"en", false )
		// we are not interested in the current locale, we just force the source code locale. marktr does not return a translated string, anyway.
		return i18n?i18n.marktr(text):text
	}       
    
    
	/**
	 * Get the current locale - either from the session, or from the browser's language
	 */
	private String getCurrentLocale(){
		
		def currentLocale = null
		
		try{
			def request = RCH.currentRequestAttributes().currentRequest
			def session = RCH.currentRequestAttributes().session

			currentLocale = session?.getAttribute("org.springframework.web.servlet.i18n.SessionLocaleResolver.LOCALE")
			currentLocale = currentLocale?currentLocale:request?.getLocale()
		} catch( Exception e ){
			// no implementation. This could be an IllegalStateException because we try to access the session during bootstrap when there is no session available... 
		}
				
		// Fallbacks		
		if( !currentLocale ){
			currentLocale = ApplicationHolder?.application?.config?.I18nGettext?.sourceCodeLocale ?:"en"			
		}
		
		return currentLocale.toString()		
	}
    
    
    /**
     * Get an I18n from the I81nFactoy and set the current locale and source code locale.
     */
	private getI18nObject( wantLocale=null, forceSourceCodeLocale=null, inSession=true ) {
    	
		def i18n = null
		try{
			
			def language = ""
			def country = ""
			def variant = ""
						def request			def session			if( inSession ){				request = RCH.currentRequestAttributes().currentRequest				session = RCH.currentRequestAttributes().session			}				

			// use locale string forced by the method call or from the session.
			if ( wantLocale==null ){
				wantLocale = getCurrentLocale()
			}
			def wantedLocale = null
			try{
				language = wantLocale?.split("_")[0].toLowerCase()
				country = wantLocale?.split("_")[1].toUpperCase()
				variant = wantLocale?.split("_")[2]
			} catch( ArrayIndexOutOfBoundsException aioe0 ){
				// ignore
			}
			wantedLocale = new Locale( language, country, variant )
			
			
			// use source code locale string forced by the method call or from config or use the bailout "en"
			if ( forceSourceCodeLocale==null ){
				forceSourceCodeLocale = ApplicationHolder?.application?.config?.I18nGettext?.sourceCodeLocale ?:"en"
			}
			def wantedSourceCodeLocale = null
			language = ""
			country = ""
			variant = ""
			try{
				language = forceSourceCodeLocale?.split("_")[0].toLowerCase()
				country = forceSourceCodeLocale?.split("_")[1].toUpperCase()
				variant = forceSourceCodeLocale?.split("_")[2]
			} catch( ArrayIndexOutOfBoundsException aioe1 ){
				// ignore
			}
			wantedSourceCodeLocale = new Locale( language, country, variant )
			
			i18n = I18nFactory.getI18n( T9nService.class, "i18ngettext.Messages" )
			i18n.setSourceCodeLocale( wantedSourceCodeLocale )
			i18n.setLocale( wantedLocale )
			
		} catch( MissingResourceException mre ){
			log.error( mre.getMessage()+". Key: "+mre.getKey()+" Class: "+mre.getClassName() )
			return null
		}
		
		return i18n
	}
	
}